package com.yuanlrc.campus_market.constant;
/**
 * 关于session的所有常量统一存放类
 * @author Administrator
 *
 */
public class SessionConstant {

	public static final String SESSION_USER_LOGIN_KEY = "ylrc_user";
	
	public static final String SESSION_STUDENT_LOGIN_KEY = "ylrc_student";
}
